package com.example.registration;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class AdminLogin extends AppCompatActivity {
    EditText UNID, pwd;
    Button login;
    TextView txt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);

        UNID=findViewById(R.id.und);
        pwd=findViewById(R.id.Password);
        login=findViewById(R.id.Login);
        txt=findViewById(R.id.userlog);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkdata();
            }
        });
        txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminLogin.this, Login.class);
                startActivity(intent);
            }
        });
    }

    boolean isEmpty(EditText text) {
        CharSequence str = text.getText().toString();
        return TextUtils.isEmpty(str);
    }
        void checkdata ()
        {
            if (isEmpty(UNID)) {
                UNID.setError("USN is required!");
            }
            if (isEmpty(pwd)) {
                pwd.setError("Password is required!");
            }
        }

}