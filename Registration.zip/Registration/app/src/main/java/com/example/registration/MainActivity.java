package com.example.registration;

import static android.view.View.Z;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    String[] stream={"Information Science and Engineering","Computer Science and Engineering","Electronics and Communications Engineering","Mechanical Engineering"};


    EditText Name,Email,USN,pwd,pwdchk;
    Button reg;
    TextView txtlog, txtad;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Spinner spin1= findViewById(R.id.stream);

        Name=findViewById(R.id.name);
        Email=findViewById(R.id.editTextTextEmailAddress);
        USN= findViewById(R.id.usn);
        pwd= findViewById(R.id.Password);
        pwdchk=findViewById(R.id.Passwordcheck);
        reg=findViewById(R.id.Reg);
        txtlog=findViewById(R.id.loginop);
        txtad= findViewById(R.id.adminlog);
        spin1.setOnItemSelectedListener(this);
        ArrayAdapter st = new ArrayAdapter(this,android.R.layout.simple_spinner_item,stream);
        st.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin1.setAdapter(st);

        txtlog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(MainActivity.this, Login.class);
                startActivity(intent);
            }
        });
        txtad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(MainActivity.this, AdminLogin.class);
                startActivity(intent);
            }
        });





        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkdata();
            }
        });
    }
    boolean isEmail(EditText text) {
        CharSequence email = text.getText().toString();
        return (!TextUtils.isEmpty(email) && Patterns.EMAIL_ADDRESS.matcher(email).matches());
    }

    boolean isEmpty(EditText text) {
        CharSequence str = text.getText().toString();
        return TextUtils.isEmpty(str);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Toast.makeText(getApplicationContext(),"Your stream is " + stream[position], Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    void checkdata() {
        if (isEmpty(Name)) {
            Toast t = Toast.makeText(this, "You must enter Name to register!", Toast.LENGTH_SHORT);
            t.show();
        }

        if (isEmpty(USN)) {
            USN.setError("USN is required!");
        }

        if (isEmail(Email) == false) {
            Email.setError("Enter valid email!");
        }
        if (isEmpty(pwd))
        {
            pwd.setError("A password is required!");

        }
        if (isEmpty(pwdchk))
        {
            pwdchk.setError("Retype password is required");
        }
        if (!isEmpty(pwd)&&!isEmpty(pwdchk))
        {
            String p1= pwd.getText().toString();
            String p2= pwdchk.getText().toString();
            if(p1.length()<=7)
            {
                Toast.makeText(this,"Password must be greater than 7 characters!",Toast.LENGTH_SHORT).show();
                pwd.setText("");
                pwdchk.setText("");
            }
            if(!p1.equals(p2))
            {
                Toast.makeText(this,"The 2 passwords don't match",Toast.LENGTH_SHORT).show();
                pwd.setText("");
                pwdchk.setText("");
            }
        }
        if(!isEmpty(USN))
        {
            String usn = USN.getText().toString();
            if(usn.length()!=10)
            {
                Toast.makeText(this,"The USN is invalid!",Toast.LENGTH_SHORT).show();
                USN.setText("");
            }
        }

    }
}